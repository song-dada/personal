document.addEventListener("DOMContentLoaded", ()=>{
	
	
	
	
	
	
	
	
})//전체 끝부분...........................